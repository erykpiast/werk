/**
 * The browser test harness (#werk-test, #werk-v0-seams). Each test gets its own copy of the
 * fixture project, made a git repository, with the fake agent first on the PATH as `claude`.
 * The real werk server runs on it, on a free port, from a copy of the app that the test may
 * edit (#werk-test-app-copy). The page may reach only that server.
 * Local storage starts empty. After the test, the harness saves one full-page screenshot as
 * evidence. The assertions read the page's structure; the picture is for a person to look at.
 */
import { test as base, expect } from '@playwright/test'
import { spawn, spawnSync, type ChildProcess, type ChildProcessByStdio } from 'node:child_process'
import { cpSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type { Readable } from 'node:stream'
import { copyApp, type AppCopy } from '../src/test/app-copy.ts'
import type { FakeScript } from '../src/test/fake-agent.ts'
import { writeFakeAgent } from '../src/test/fake-bin.ts'

const ROOT = join(import.meta.dirname, '..')
const MAIN = join(ROOT, 'src', 'cli', 'main.ts')
const FIXTURE = join(import.meta.dirname, 'fixture-project')
const BOOT_TIMEOUT_MS = 20_000

export type Werk = {
  /** The address of the server, with a trailing slash. */
  url: string
  /** The project directory the server serves. */
  dir: string
  /** The copy of the app the server runs from. A test that edits werk's code edits this copy. */
  app: AppCopy
  /** Runs the werk command line in the project, the way an agent does. Throws on a non-zero exit. */
  cli: (args: string[]) => string
  /** Starts the werk command line in the project and does not wait for it. `exited` gives its exit code. */
  start: (args: string[]) => { exited: Promise<number | null> }
  /** Sets the script that the fake agent replays from its next launch. */
  scriptAgent: (script: FakeScript) => void
  /** Every argv the fake agent got, in launch order. */
  agentLaunches: () => string[][]
  /** Every launch of the fake agent, in launch order: its role, its pid, and the JSON lines it read on stdin. */
  agentRuns: () => { role?: string; pid: number; inputs: unknown[] }[]
}

export const test = base.extend<{ werk: Werk }>({
  werk: [
    async ({ page }, use, testInfo) => {
      const root = mkdtempSync(join(tmpdir(), 'werk-e2e-'))
      const app = copyApp()
      const dir = join(root, 'project')
      const bin = join(root, 'bin')
      cpSync(FIXTURE, dir, { recursive: true })
      writeFakeAgent(bin, app.fakeAgent)
      // No script until the test installs one: a launch before that fails (#werk-test-external).
      const scriptPath = join(root, 'agent-script.json')
      const launchLog = join(root, 'agent-launches.jsonl')
      const inputLog = join(root, 'agent-input.jsonl')
      writeFileSync(launchLog, '')
      writeFileSync(inputLog, '')

      // A clean environment: an inherited WERK_LOG would point the server at a real map. Every
      // process the harness starts gets this environment and nothing else.
      const env = {
        PATH: `${bin}:${process.env.PATH ?? ''}`,
        HOME: root,
        TMPDIR: tmpdir(),
        GIT_CONFIG_NOSYSTEM: '1',
        GIT_CONFIG_GLOBAL: '/dev/null',
        WERK_FAKE_AGENT_SCRIPT: scriptPath,
        WERK_FAKE_AGENT_LOG: launchLog,
        WERK_FAKE_AGENT_INPUT: inputLog,
      }
      const run = (cmd: string, args: string[]) => {
        const r = spawnSync(cmd, args, { cwd: dir, env, encoding: 'utf8' })
        if (r.status !== 0) throw new Error(`${cmd} ${args.join(' ')} exited ${r.status}: ${r.stderr}`)
        return r.stdout
      }
      run('git', ['init', '--quiet', '--initial-branch=main'])
      // A build commits each pass in the project, so the repository names its committer.
      run('git', ['config', 'user.name', 'werk test'])
      run('git', ['config', 'user.email', 'test@werk.invalid'])
      run('git', ['config', 'commit.gpgsign', 'false'])
      run('git', ['add', '.'])
      run('git', ['commit', '--quiet', '-m', 'The fixture'])
      const started: ChildProcess[] = []
      const start = (args: string[]) => {
        const child = spawn('bun', [MAIN, ...args], { cwd: dir, env, stdio: 'ignore' })
        started.push(child)
        return { exited: new Promise<number | null>((resolve) => child.once('exit', resolve)) }
      }

      // The test server refuses to start when the fake agent is not first on PATH.
      const server = spawn('bun', [app.testServer, '--port', '0'], { cwd: dir, env, stdio: ['ignore', 'pipe', 'pipe'] })
      try {
        const url = await addressOf(server)
        const host = new URL(url).host
        await page.context().route('**/*', (route) =>
          new URL(route.request().url()).host === host ? route.continue() : route.abort('blockedbyclient'),
        )
        // Clear local storage before the app's first script runs, once per tab. The flag in
        // session storage survives a reload, so a test that reloads keeps what the page stored.
        await page.addInitScript(() => {
          if (sessionStorage.getItem('werk-test-cleared')) return
          localStorage.clear()
          sessionStorage.setItem('werk-test-cleared', '1')
        })
        await page.goto(url)

        try {
          await use({
            url,
            dir,
            app,
            cli: (args) => run('bun', [MAIN, ...args]),
            start,
            scriptAgent: (script) => writeFileSync(scriptPath, JSON.stringify(script)),
            agentLaunches: () => jsonLines<{ argv: string[] }>(launchLog).map((l) => l.argv),
            agentRuns: () => {
              const inputs = jsonLines<{ pid: number; message: unknown }>(inputLog)
              return jsonLines<{ role?: string; pid: number }>(launchLog).map(({ role, pid }) => ({
                ...(role !== undefined && { role }),
                pid,
                inputs: inputs.filter((i) => i.pid === pid).map((i) => i.message),
              }))
            },
          })
        } finally {
          // A failed test keeps its picture too. A page that cannot be drawn must not hide the failure.
          await page.screenshot({ path: testInfo.outputPath('evidence.png'), fullPage: true }).catch(() => {})
        }
      } finally {
        for (const child of started) await stop(child)
        await stop(server)
        rmSync(root, { recursive: true, force: true })
        app.remove()
      }
    },
    // Every test gets the server and the screenshot, also a test that never names the fixture.
    { auto: true },
  ],
})

export { expect }

const jsonLines = <T>(path: string): T[] =>
  readFileSync(path, 'utf8')
    .split('\n')
    .filter(Boolean)
    .map((line) => JSON.parse(line) as T)

type Server = ChildProcessByStdio<null, Readable, Readable>

/** Waits for the line where the server prints its address. */
function addressOf(server: Server): Promise<string> {
  return new Promise((resolve, reject) => {
    let out = ''
    let err = ''
    const timer = setTimeout(() => reject(new Error(`werk serve printed no address. stderr: ${err}`)), BOOT_TIMEOUT_MS)
    server.stderr.on('data', (chunk: Buffer) => (err += chunk.toString()))
    server.stdout.on('data', (chunk: Buffer) => {
      out += chunk.toString()
      const m = out.match(/http:\/\/\S+\//)
      if (m) {
        clearTimeout(timer)
        resolve(m[0])
      }
    })
    server.on('exit', (code) => {
      clearTimeout(timer)
      reject(new Error(`werk serve exited ${code}. stderr: ${err}`))
    })
  })
}

async function stop(server: ChildProcess): Promise<void> {
  if (server.exitCode !== null || server.signalCode !== null) return
  const exited = new Promise((resolve) => server.once('exit', resolve))
  server.kill('SIGTERM')
  const timer = setTimeout(() => server.kill('SIGKILL'), 5_000)
  await exited
  clearTimeout(timer)
}
